
package farics;

public class alatTulis extends alat {
    static String fungsi,ukuran;
    static Double pjg,lbr;
    
    public void fungsi(){
     System.out.print("fungsi = ");
     fungsi = masuk.next();
    }
    public void ukuran(){
     System.out.print("panjang = ");
     pjg = masuk.nextDouble();
     System.out.print("lebar = ");
     lbr = masuk.nextDouble();
    }
}
