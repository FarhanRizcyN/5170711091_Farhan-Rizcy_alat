
package farics;

public class alatKesehatan extends alat {
    static String manfaat,jenis;
    
    public void jenis(){
     System.out.print("jenis = ");
     jenis = masuk.next();
    }
    public void manfaat(){
     System.out.print("manfaat = ");
     manfaat = masuk.next();
    }
}
