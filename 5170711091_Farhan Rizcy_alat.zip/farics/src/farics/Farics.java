
package farics;
import java.util.Scanner;
public class Farics {

  public static void main(String[] args) {
   double jml,no,ulang;
   Scanner masuk = new Scanner(System.in);
   alat macam = new alat();
   alatTulis beli = new alatTulis();
   alatMandi wangi = new alatMandi();
   alatKesehatan sehat = new alatKesehatan();
   double Y = 0;
    do{
      System.out.println("1.Alat Tulis");
      System.out.println("2.Alat Mandi");
      System.out.println("3.Alat Kesehatan");
      System.out.print("jumlah alat :");
      jml = masuk.nextDouble();
        
      for (int a = 1; a <= jml; a++) {
       System.out.println("\nData Ke-" + a);
            
      System.out.print("masukkan pilihan :");
      no = masuk.nextDouble();
      if(no==1){
         macam.namaBarang();
         macam.merkProduct();
         macam.hargaBarang();
         beli.fungsi();
         beli.ukuran();
         System.out.println("Nama = " + alat.nama);
         System.out.println("Merk = " + alat.merk);
         System.out.println("Harga = " + alat.harga);
         System.out.println("Fungsi = " + alatTulis.fungsi);
         System.out.println("Ukuran = " + alatTulis.ukuran);
         }
      else if(no==2){
         macam.namaBarang();
         macam.merkProduct();
         macam.hargaBarang();
         wangi.wujud();
         wangi.warna();
         System.out.println("Nama = " + alat.nama);
         System.out.println("Merk = " + alat.merk);
         System.out.println("Harga = " + alat.harga);
         System.out.println("Wujud = " + alatMandi.wujud);
         System.out.println("Warna = " + alatMandi.warna);
        }
       else if(no==3){
          macam.namaBarang();
          macam.merkProduct();
          macam.hargaBarang();
          sehat.jenis();
          sehat.manfaat();
          System.out.println("Nama = " + alat.nama);
          System.out.println("Merk = " + alat.merk);
          System.out.println("Harga = " + alat.harga);
          System.out.println("Jenis = " + alatKesehatan.jenis);
          System.out.println("Manfaat = " + alatKesehatan.manfaat);
        }
       else{
        System.out.print("----------------");
        }
      System.out.println("");
      System.out.println("----------------------");
      System.out.println("");
     }
     System.out.print("ulangi ? [Y=0/N=1]");
     ulang = masuk.nextDouble();
    }
     while(ulang == Y);
 } 
}

