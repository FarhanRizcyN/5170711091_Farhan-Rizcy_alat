
package farics;

public class alatMandi extends alat {
    static String warna,wujud;
    
    public void wujud(){
     System.out.print("wujud = ");
     wujud = masuk.next();
    }
    public void warna(){
     System.out.print("warna = ");
     warna = masuk.next();
    }
}
