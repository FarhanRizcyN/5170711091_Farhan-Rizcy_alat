
package farics;
import java.util.Scanner;
public class alat {
  static String nama,merk;
  static Float harga;
  static Scanner masuk = new Scanner(System.in);
  
  public void namaBarang(){
   System.out.print("nama Barang = ");
   nama = masuk.next();
  }
  public void merkProduct(){
   System.out.print("merk / Product = ");
   merk = masuk.next();
  }
  public void hargaBarang(){
   System.out.print("harga Barang = ");
   harga = masuk.nextFloat();
  }   
}
